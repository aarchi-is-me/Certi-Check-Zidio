import React, { useState, useEffect } from 'react';
import axios from 'axios';

const StudentTable = () => {
    const [students, setStudents] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchStudents = async () => {
            try {
                // Fetch data from the API
                const response = await axios.get('http://localhost:3001/getStudents');
                console.log(response.data);
                setStudents(response.data)
            } catch (error) {
                setError(error.message);
            }
        };

        fetchStudents();
    }, []);

    return (
        <div className="p-4">
            <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                    <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Field</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Date</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Date</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    {
                        students.map(student => (
                                <tr>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-red-900">{student.student_id}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.student_name}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.course_field}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.start_date}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.end_date}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.enrollment_status}</td>
                                </tr>
                        ))
                    }
                </tbody>
            </table>
        </div>
    );
};

export default StudentTable;
