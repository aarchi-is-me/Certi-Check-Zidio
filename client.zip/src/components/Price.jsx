import React from "react";

function Price () {
    return (
        <h1>PRICE LIST</h1>
    );
}

export default Price;