// src/DownloadButton.js
import React from 'react';
import axios from 'axios';

function DownloadButton({ studentId }) {
  const handleDownload = async () => {
    try {
      const response = await axios.post('http://YOUR_BACKEND_URL_HERE/tokens', { studentId });
      console.log('Token created:', response.data);
      // You can add more logic here to trigger a download or notify the user
    } catch (error) {
      console.error('Error creating token:', error);
    }
  };

  return (
    <button onClick={handleDownload}>Download Certificate</button>
  );
}

export default DownloadButton;