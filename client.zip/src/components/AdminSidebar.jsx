// Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom'; // Assuming you're using React Router for navigation

const AdminSidebar = () => {
    return (
        <div className="w-64 h-screen bg-gray-800 text-white shadow-md fixed top-0 left-0">
            <h2 className="text-2xl font-semibold p-4">Admin Dashboard</h2>
            <ul className="mt-6">
                <li>
                    <Link to="/stab" className="block px-4 py-2 hover:bg-gray-700">Student Data</Link>
                </li>
                {/* <li>
                    <Link to="/data-management" className="block px-4 py-2 hover:bg-gray-700">Data Management</Link>
                </li>
                <li>
                    <Link to="/user-management" className="block px-4 py-2 hover:bg-gray-700">User Management</Link>
                </li>
                <li>
                    <Link to="/settings" className="block px-4 py-2 hover:bg-gray-700">Settings</Link>
                </li> */}
            </ul>
        </div>
    );
};

export default AdminSidebar;
