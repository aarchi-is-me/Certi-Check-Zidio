import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import axios from 'axios';
import AdminSidebar from './AdminSidebar'; // Import the Sidebar component

function AdminDash() {
    const [sheets, setSheets] = useState([]);
    const [data, setData] = useState([]);
    const [workbook, setWorkbook] = useState(null);

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (!file) {
            return; // If no file is selected, exit the function
        }

        const reader = new FileReader();
        reader.readAsBinaryString(file);
        reader.onload = (e) => {
            const data = e.target.result;
            const workbook = XLSX.read(data, { type: 'binary' });
            const sheetNames = workbook.SheetNames;
            setSheets(sheetNames);
            setWorkbook(workbook);  // Store the workbook in state
            loadSheetData(workbook, sheetNames[0]); // Set the first sheet as the default
        };
    };

    const loadSheetData = (workbook, sheetName) => {
        const sheet = workbook.Sheets[sheetName];
        const parsedData = XLSX.utils.sheet_to_json(sheet);
        setData(parsedData);
    };

    const handleSheetChange = (sheetName) => {
        loadSheetData(workbook, sheetName);  // Use the stored workbook
    };

    const handleSubmit = async () => {
        try {
            const response = await axios.post('http://localhost:3001/saveData', data);
            if (response.status === 200) {
                alert('Data saved successfully');
            }
        } catch (error) {
            console.error('Error saving data:', error);
            alert('Failed to save data');
        }
    };

    return (
        <div className="flex">
            <AdminSidebar /> {/* Add Sidebar component */}
            <div className="flex-1 p-8 ml-64">
                <h1 className="text-3xl sm:text-4xl lg:text-6xl text-center font-bold mb-6">Welcome Admin!</h1>
                <p className="text-sm sm:text-lg text-white-700 text-center mb-6">Please choose your .xlsx / .xls file to be uploaded</p>
                <input
                    type="file"
                    accept=".xlsx, .xls"
                    onChange={handleFileUpload}
                    className="block w-full text-blue-500 bg-blue-100 border border-blue-500 rounded py-2 px-4 mb-4 cursor-pointer"
                />
                {sheets.length > 0 && (
                    <div className="flex justify-around mb-4">
                        {sheets.map((sheet, index) => (
                            <button
                                key={index}
                                onClick={() => handleSheetChange(sheet)}
                                className="bg-blue-500 text-white py-2 px-4 rounded transition duration-200 ease-in-out hover:bg-blue-700 border border-blue-500"
                            >
                                {sheet}
                            </button>
                        ))}
                    </div>
                )}
                {data.length > 0 && (
                    <div className="overflow-x-auto">
                        <table className="min-w-full text-center bg-white border border-gray-200">
                            <thead className="bg-blue-500 text-white">
                                <tr>
                                    {Object.keys(data[0]).map((key) => (
                                        <th key={key} className="border border-gray-300 py-2 px-4">
                                            {key}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {data.map((row, index) => (
                                    <tr key={index} className="odd:bg-gray-100 even:bg-gray-50">
                                        {Object.values(row).map((value, index) => (
                                            <td key={index} className="border border-gray-300 py-2 px-4">
                                                {value}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
                <div className="flex justify-end mt-6">
                    <button
                        onClick={handleSubmit}
                        className="bg-blue-500 text-white py-2 px-6 rounded transition duration-200 ease-in-out hover:bg-blue-700 border border-blue-500"
                    >
                        Submit
                    </button>
                </div>
            </div>
        </div>
    );
}

export default AdminDash;
